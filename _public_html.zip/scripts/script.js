// Array para almacenar las empresas registradas
        let companies = [];
        let filtroActual = 'todos'; // El filtro activo por defecto
        
        // 1. INICIALIZACIÓN Y CARGA DE DATOS
        document.addEventListener('DOMContentLoaded', function() {
            // Inicializa los sistemas de pestañas y filtros
            inicializarPestanas();
            inicializarFiltros();
            
            // Carga datos guardados del almacenamiento local
            const empresasGuardadas = localStorage.getItem('sustainableCompanies');
            const reflexionGuardada = localStorage.getItem('sustainabilityReflection');
            
            if (empresasGuardadas) {
                companies = JSON.parse(empresasGuardadas);
                actualizarListaEmpresas();
                actualizarEstadisticas();
            }
            
            if (reflexionGuardada) {
                document.getElementById('textoReflexion').value = reflexionGuardada;
            }
        });
        
        // Inicializa el sistema de pestañas esto es para manejar que mostrar segun el click que hagas en el nav basicamente le quitamos lo de activo a la que la tenga actualmente y se lo ponemos a la que la has dado click
        function inicializarPestanas() {
            const pestanas = document.querySelectorAll('.pestana');
            pestanas.forEach(pestana => {
                pestana.addEventListener('click', function() {
                    // 1. Remueve la clase activo de todas las pestañas
                    pestanas.forEach(t => t.classList.remove('activo'));
                    // 2. Añade la clase activo a la pestaña clickeada
                    this.classList.add('activo');
                    
                    // 3. Oculta todos los contenidos de pestaña
                    document.querySelectorAll('.contenido-pestana').forEach(contenido => {
                        contenido.classList.remove('activo');
                    });
                    
                    // 4. Muestra el contenido correspondiente usando el atributo 'data-pestana'
                    const idContenido = this.getAttribute('data-pestana');
                    document.getElementById(`${idContenido}-pestana`).classList.add('activo');
                });
            });
        }
        
        // Inicializa el sistema de filtros
        function inicializarFiltros() {
            const botonesFiltro = document.querySelectorAll('.boton-filtro');
            botonesFiltro.forEach(btn => {
                btn.addEventListener('click', function() {
                    // 1. Remueve la clase activo de todos los botones
                    botonesFiltro.forEach(b => b.classList.remove('activo'));
                    // 2. Añade la clase activo al botón clickeado
                    this.classList.add('activo');
                    
                    // 3. Actualiza el filtro actual y la lista
                    filtroActual = this.getAttribute('data-filtro');
                    actualizarListaEmpresas();
                });
            });
        }
        
        // 2. MANEJO DE FORMULARIO Y DATOS
        // Manejar el envío del formulario de registro
        document.getElementById('formularioEmpresa').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Obtener valores de los campos
            const name = document.getElementById('nombreEmpresa').value;
            const sector = document.getElementById('sectorEmpresa').value;
            const description = document.getElementById('descripcionEmpresa').value;
            const ods = document.getElementById('odsEspecificos').value;
            const impact = document.getElementById('impactoEmpresa').value;
            
            // Obtener ámbitos seleccionados
            const ambiental = document.getElementById('ambitoAmbiental').checked;
            const social = document.getElementById('ambitoSocial').checked;
            const economico = document.getElementById('ambitoEconomico').checked;
            
            const scopes = [];
            if (ambiental) scopes.push('ambiental');
            if (social) scopes.push('social');
            if (economico) scopes.push('economico');
            
            // Validar que al menos un ámbito esté seleccionado
            if (scopes.length === 0) {
                mostrarNotificacion('Por favor, selecciona al menos un ámbito ODS', 'error');
                return;
            }
            
            // Crear objeto empresa
            const company = {
                id: Date.now(), // ID único basado en timestamp
                name: name,
                sector: sector,
                description: description,
                ods: ods,
                impact: impact,
                scopes: scopes, // Contiene 'ambiental', 'social', 'economico'
                date: new Date().toLocaleDateString('es-ES')
            };
            
            // Agregar al array y actualizar
            companies.push(company);
            actualizarListaEmpresas();
            actualizarEstadisticas();
            guardarEnAlmacenamientoLocal();
            
            // Limpiar formulario
            document.getElementById('formularioEmpresa').reset();
            mostrarNotificacion(`Empresa "${name}" agregada correctamente`, 'success');
        });
        
        // Actualizar la lista de empresas en el DOM
        function actualizarListaEmpresas() {
            const listaEmpresas = document.getElementById('listaEmpresas');
            
            // Filtrar empresas según el filtro activo
            let empresasFiltradas = companies;
            if (filtroActual !== 'todos') {
                empresasFiltradas = companies.filter(company => 
                    company.scopes.includes(filtroActual)
                );
            }
            
            // Mostrar mensaje si no hay resultados
            if (empresasFiltradas.length === 0) {
                listaEmpresas.innerHTML = '<p class="sin-resultados">No hay empresas que coincidan con el filtro seleccionado.</p>';
                return;
            }
            
            listaEmpresas.innerHTML = '';
            
            // Crear la tarjeta (article) para cada empresa filtrada
            empresasFiltradas.forEach(company => {
                const tarjetaEmpresa = document.createElement('article'); 
                tarjetaEmpresa.className = 'tarjeta-empresa';
                
                tarjetaEmpresa.innerHTML = `
                    <header class="cabecera-empresa">
                        <div>
                            <div class="nombre-empresa">${company.name}</div>
                            <div><strong>Sector:</strong> ${obtenerNombreSector(company.sector)}</div>
                        </div>
                        <div class="acciones-empresa">
                            <button class="boton-accion" onclick="editarEmpresa(${company.id})" title="Editar">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="boton-accion" onclick="eliminarEmpresa(${company.id})" title="Eliminar">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </header>
                    <p><strong>Actividad:</strong> ${company.description}</p>
                    <div class="etiquetas-ods">
                        ${company.scopes.map(scope => 
                            `<span class="etiqueta-ods ${scope}">${obtenerNombreAmbito(scope)}</span>`
                        ).join('')}
                    </div>
                    <p><strong>ODS:</strong> ${company.ods}</p>
                    <p><strong>Impacto:</strong> ${company.impact}</p>
                    <footer><small>Registrado el: ${company.date}</small></footer>
                `;
                
                listaEmpresas.appendChild(tarjetaEmpresa);
            });
        }
        
        // Actualizar los contadores y barras de progreso en el header
        function actualizarEstadisticas() {
            document.getElementById('totalCompanies').textContent = companies.length;
            
            // Contar por ámbito simplemente contamos los que hay en el array de scopes
            const countAmbiental = companies.filter(c => c.scopes.includes('ambiental')).length;
            const countSocial = companies.filter(c => c.scopes.includes('social')).length;
            const countEconomico = companies.filter(c => c.scopes.includes('economico')).length;
            
            document.getElementById('environmentalCompanies').textContent = countAmbiental;
            document.getElementById('socialCompanies').textContent = countSocial;
            document.getElementById('economicCompanies').textContent = countEconomico;
            
            // Actualizar barras de progreso (en %) como odio los %
            const total = companies.length;
            document.getElementById('environmentalProgress').style.width = total > 0 ? (countAmbiental / total * 100) + '%' : '0%';
            document.getElementById('socialProgress').style.width = total > 0 ? (countSocial / total * 100) + '%' : '0%';
            document.getElementById('economicProgress').style.width = total > 0 ? (countEconomico / total * 100) + '%' : '0%';
        }
        
        // Helpers para obtener nombres legibles
        function obtenerNombreSector(sectorKey) {
            const sectores = {
                'energia': 'Energías renovables',
                'conservacion': 'Conservación ambiental',
                'tecnologia': 'Tecnología sostenible',
                'alimentacion': 'Alimentación sostenible',
                'moda': 'Moda ética',
                'finanzas': 'Finanzas sostenibles',
                'construccion': 'Construcción sostenible',
                'movilidad': 'Movilidad sostenible',
                'otros': 'Otros'
            };
            return sectores[sectorKey] || 'No especificado';
        }
        
        function obtenerNombreAmbito(scopeKey) {
            const ambitos = {
                'ambiental': 'Ambiental',
                'social': 'Social',
                'economico': 'Económico'
            };
            return ambitos[scopeKey] || scopeKey;
        }
        
        // 3. ACCIONES Y UTILIDADES
        // Eliminar empresa
        function eliminarEmpresa(id) {
            if (confirm('¿Estás seguro de que quieres eliminar esta empresa?')) {
                companies = companies.filter(company => company.id !== id);
                actualizarListaEmpresas();
                actualizarEstadisticas();
                guardarEnAlmacenamientoLocal();
                mostrarNotificacion('Empresa eliminada correctamente', 'success');
            }
        }
        
        // Editar empresa (carga datos en el formulario)
        function editarEmpresa(id) {
            const company = companies.find(c => c.id === id);
            if (company) {
                // Llenar el formulario con los datos de la empresa
                document.getElementById('nombreEmpresa').value = company.name;
                document.getElementById('sectorEmpresa').value = company.sector;
                document.getElementById('descripcionEmpresa').value = company.description;
                document.getElementById('odsEspecificos').value = company.ods;
                document.getElementById('impactoEmpresa').value = company.impact;
                
                // Marcar/desmarcar los ámbitos
                document.getElementById('ambitoAmbiental').checked = company.scopes.includes('ambiental');
                document.getElementById('ambitoSocial').checked = company.scopes.includes('social');
                document.getElementById('ambitoEconomico').checked = company.scopes.includes('economico');
                
                // Eliminar la empresa para reemplazarla después de editar
                companies = companies.filter(c => c.id !== id);
                actualizarListaEmpresas();
                actualizarEstadisticas();
                
                mostrarNotificacion(`Editando empresa: ${company.name}. Haz click en 'Agregar empresa' para guardar los cambios.`, 'info');
            }
        }
        
        // Guarda el array de empresas en el almacenamiento local del navegador
        function guardarEnAlmacenamientoLocal() {
            localStorage.setItem('sustainableCompanies', JSON.stringify(companies));
        }
        
        // Guarda el texto de la reflexión
        function guardarReflexion() {
            const reflexion = document.getElementById('textoReflexion').value;
            localStorage.setItem('sustainabilityReflection', reflexion);
            mostrarNotificacion('Reflexión guardada correctamente', 'success');
        }
        
        // Muestra una notificación temporal en la esquina superior derecha
        function mostrarNotificacion(message, type) {
            // ... (Lógica de notificación, no se renombra por ser código de utilidad) ...
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                border-radius: 5px;
                color: white;
                z-index: 1000;
                font-weight: bold;
                box-shadow: 0 3px 10px rgba(0,0,0,0.2);
                animation: slideIn 0.3s ease-out;
            `;
            
            // Estilo según el tipo
            if (type === 'success') {
                notification.style.background = 'var(--primario)';
            } else if (type === 'error') {
                notification.style.background = 'var(--peligro)';
            } else {
                notification.style.background = 'var(--info)';
            }
            
            notification.textContent = message;
            document.body.appendChild(notification);
            
            // Eliminar después de 3 segundos
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease-in';
                setTimeout(() => {
                    document.body.removeChild(notification);
                }, 300);
            }, 3000);
            
            // Asegurar que las animaciones de notificación existan
            let style = document.getElementById('notification-styles');
            if (!style) {
                 style = document.createElement('style');
                 style.id = 'notification-styles';
                 style.textContent = `
                    @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
                    @keyframes slideOut { from { transform: translateX(0); opacity: 1; } to { transform: translateX(100%); opacity: 0; } }
                 `;
                 document.head.appendChild(style);
            }
        }
        
        // Exportar datos a diferentes formatos
        function exportarDatos(format) {
            if (companies.length === 0) {
                mostrarNotificacion('No hay datos para exportar.', 'error');
                return;
            }
            
            let dataStr, fileName, mimeType;
            
            if (format === 'json') {
                dataStr = JSON.stringify(companies, null, 2);
                fileName = 'empresas_sostenibles.json';
                mimeType = 'application/json';
            } else if (format === 'pdf') {
                // Simulación de exportación a PDF
                mostrarNotificacion('Exportación a PDF simulada. En una implementación real, se usaría una librería (ej. jsPDF).', 'info');
                return;
            } else if (format === 'html') {
                // Generar HTML con los datos
                let htmlContent = `
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <title>Empresas Sostenibles - Reporte</title>
                        <style>
                            body { font-family: Arial, sans-serif; margin: 20px; }
                            h1 { color: var(--primario); }
                            .empresa { border: 1px solid #ddd; padding: 15px; margin: 10px 0; border-radius: 5px; }
                            .etiquetas { margin: 10px 0; }
                            .etiqueta { display: inline-block; background: #4c82afff; color: white; padding: 3px 8px; border-radius: 12px; margin-right: 5px; }
                        </style>
                    </head>
                    <body>
                        <h1>Reporte de Empresas Sostenibles</h1>
                        <p>Generado el ${new Date().toLocaleDateString('es-ES')}</p>
                        <p>Total de empresas: ${companies.length}</p>
                `;
                
                companies.forEach(company => {
                    htmlContent += `
                        <div class="empresa">
                            <h2>${company.name}</h2>
                            <p><strong>Sector:</strong> ${obtenerNombreSector(company.sector)}</p>
                            <p><strong>Actividad:</strong> ${company.description}</p>
                            <div class="etiquetas">
                                ${company.scopes.map(scope => `<span class="etiqueta">${obtenerNombreAmbito(scope)}</span>`).join('')}
                            </div>
                            <p><strong>ODS:</strong> ${company.ods}</p>
                            <p><strong>Impacto:</strong> ${company.impact}</p>
                            <p><small>Registrado el: ${company.date}</small></p>
                        </div>
                    `;
                });
                
                dataStr = htmlContent;
                fileName = 'empresas_sostenibles.html';
                mimeType = 'text/html';
            }
            
            // Crear y descargar el archivo
            const blob = new Blob([dataStr], { type: mimeType });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            mostrarNotificacion(`Datos exportados como ${fileName}`, 'success');
        }